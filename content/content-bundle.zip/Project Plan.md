![Tekstvak:](file:///C:/Users/ICT89/AppData/Local/Temp/msohtmlclip1/01/clip_image001.png)

![Tekstvak:](file:///C:/Users/ICT89/AppData/Local/Temp/msohtmlclip1/01/clip_image002.png)

  

Inhoud

[1. Projectopdracht. 2](#_Toc128915358)

[Context. 2](#_Toc128915359)

[Doel 2](#_Toc128915360)

[Tussenresultaten. 2](#_Toc128915361)

[Begrenzing en Randvoorwaarden. 3](#_Toc128915362)

[2. Onderzoeksvragen. 3](#_Toc128915363)

[Hoofdvraag. 3](#_Toc128915364)

[Deelvragen. 3](#_Toc128915365)

[Strategie. 3](#_Toc128915366)

[3. Projectorganisatie. 5](#_Toc128915367)

[Teamleden. 5](#_Toc128915368)

[Communicatie. 5](#_Toc128915369)

[4. Activiteiten en tijdplan. 6](#_Toc128915370)

[5. Leeruitkomsten. 7](#_Toc128915371)

[Analyseren. 7](#_Toc128915372)

[Adviseren. 7](#_Toc128915373)

[Ontwerpen. 7](#_Toc128915374)

[Realiseren. 7](#_Toc128915375)

[Manage & Control 7](#_Toc128915376)

[Kritisch denken. 7](#_Toc128915377)

[Communicatie. 7](#_Toc128915378)

[Leervaardigheid. 7](#_Toc128915379)

[6. Product Breakdown Structure. 8](#_Toc128915380)

[7. Bronnen. 9](#_Toc128915381)

[Tabel 1 Scope. 4](#_Toc128227511)

[Tabel 2 Toepassing onderzoeksmethoden. 5](#_Toc128227512)

[Tabel 3 Iteraties. 6](#_Toc128227513)

**Versie**

**Aanpassingen**

**Datum**

**1**

Eerste versie

5-maart-2023

  

# 1. Projectopdracht

## Context

_Een initiatief om een duurzame leefomgeving op de campus te realiseren waarbij studenten en jongvolwassenen onderling producten en materialen kunnen uitwisselen om op deze manier verspilling en overtollige consumptie tegen te gaan._

De aanleiding voor dit project is een van de zeventien doelen van de Verenigde Naties waarbij de landen gevraagd worden om deel te nemen aan een globale samenwerking waarbij er op globale schaal actie ondernomen wordt om armoede tegen te gaan, gezondheid en scholing te verbeteren, ongelijkheid te verminderen en economische groei te steunen. Bij al deze doelen speelt het effect op het klimaat een belangrijke rol.

Doel 12 (_Ensure sustainable consumption and production patterns)_ beslaat het duurzaam consumeren en produceren. Niet-duurzame patronen van consumptie en productie zijn de grondoorzaak van deze drie globale crises.

1.       Klimaatverandering

2.       Verlies van biodiversiteit

3.       Schadelijke uitstoot

In de periode 2000-2017 zien we een toename van 70% in wereldwijde materiaalvoetafdruk (Nations, 2022). Deze toename is te wijten aan een toename aan benodigde materialen om te voorzien in de totale consumptie. Toenemende materiaalconsumptie van ontwikkelingslanden is vooral te wijten aan industrialisering waarbij materiaal intensieve productie wordt uitbesteed aan ontwikkelde landen.

Een duurzame consumptie en productie vereist benaderingen van de circulaire economie waarin de focus word gelegd op het verminderen van afval en vervuiling, producten en materialen in gebruik te houden en natuurlijke systemen te regenereren.

Blockchain-technologie kan bijdragen aan de circulaire economie door te helpen de transactiekosten te verlagen, de prestaties en communicatie in de toeleveringsketen te verbeteren, de bescherming van mensenrechten te waarborgen, de vertrouwelijkheid en het welzijn van patiënten in de gezondheidszorg te verbeteren en de koolstofvoetafdruk te verkleinen. (Upadhyay, Mukhuty, Kumar, & Kazancoglu, 2021).

Dit project biedt een mogelijke strategie en een implementatie daarvan om duurzamer om te kunnen gaan met meubilair en studieboeken onder studenten.

## Doel

Het project heeft het volgende doel: zorgen dat de consumptie van studenten en jongvolwassenen van nieuwe materialen en producten kan worden teruggedrongen met behulp van een web applicatie.

### Tussenresultaten

·         Vóór maandag 6 maart is het onderzoeksplan opgesteld.  

## Begrenzing en Randvoorwaarden

**Tot het project behoort:**

**Tot het project behoort niet:**

1.       De focus ligt op meubilair en studieboeken;

1.       Alle andere ontwikkelingsdoelen van de Verenigde Naties (Nations, 2022).;

2.       Het uitrollen van de applicatie op grote schaal;

Tabel 1 Scope

# 2. Onderzoeksvragen

## Hoofdvraag

Op welke wijze kan blockchain-technologie in de vorm van een gedecentraliseerde webapplicatie een bijdrage leveren aan circulaire economie met betrekking tot meubilair en studieboeken onder studenten?

## Deelvragen

1.       Wat wordt er verstaan onder blockchain-technologie?

2.       Op welke wijze draagt blockchain-technologie bij aan een circulaire economie?

3.       Welke ontwikkelmethode is bij uitstek geschikt voor het ontwikkelen van een gedecentraliseerde webapplicatie?

4.       Hoe zou een POC eruit kunnen zien waarbij studenten in staat zijn om in een gedecentraliseerde webapplicatie meubilair en studieboeken onderling te verhandelen?

## Strategie

Om de kennisvragen te kunnen beantwoorden is informatie nodig. Deze informatie ga ik verzamelen aan de hand van de drie onderdelen van de Development Oriented Triangulation Framework (“The DOT Framework - ICT Research Methods,” 2021).

Om de onderzoeksvragen gedegen te kunnen beantwoorden ga ik tenminste twee onderzoeksmethoden toepassen per onderzoeksvraag. Zie Tabel 2 voor de toegepaste onderzoeksmethoden per deelvraag.

**Onderzoeksvraag**

**Methode 1**

**Methode 2**

**Methode 3**

Wat wordt verstaan onder blockchain-technologie?

Bieb

Veld

-

Op welke wijze draagt blockchain-technologie bij aan een circulaire economie?

Bieb

Veld

-

Welke ontwikkelmethode is bij uitstek geschikt voor het ontwikkelen van een gedecentraliseerde webapplicatie?

Bieb

Veld

Lab

Hoe zou een proof-of-concept eruit kunnen zien waarbij studenten in staat zijn om in een gedecentraliseerde webapplicatie meubilair en studieboeken onderling te verhandelen?

Werkplaats

Showroom

-

Tabel 2 Toepassing onderzoeksmethoden

Ten eerste ligt de focus op het applicatiedomein van mijn project. Ik ga onderzoeken in welk domein mijn product toepasbaar is en hoe dit te definiëren is. Aan de hand van dit Application Domain ga ik een actieplan opstellen om alle theorie, modellen en opvattingen hieromtrent te structureren in Available Work. Tenslotte wil ik dit in de praktijk brengen in het Application Domain en een product realiseren waarmee ik een mogelijke implementatie naar een real-life toepassing wil uitwerken.

De mate waarin dit product af is zal grotendeels afhangen van de omvang van het onderzoek, de Available Work en de benodigde onderdelen die vereist zijn om een gedecentraliseerde webapplicatie op te leveren.

De onderzoeksruimte **bieb** bevat een verzameling methoden en technieken die dienen tot oriëntatie op beschikbaar werk.

De onderzoeksruimte **veld** bevat een verzameling methoden en technieken die ertoe dienen het toepassingsdomein beter te leren kennen.

De onderzoeksruimte **werkplaats** richt zich op het verbeteren van de oplossing zelf, zonder dat het onderzoek nieuwe inzichten over de toepassingscontext of de context van beschikbaar werk oplevert.

De onderzoeksruimte **lab** bevat methoden die geschikt zijn om de oplossing te toetsen aan een aspect van de toepassingscontext. Het verschil tussen lab en veld is dat veldmethoden een oriënterend karakter hebben en gericht zijn op overzicht, terwijl labstudies een meer concluderend karakter hebben en zich richten op zekerheid.

De onderzoeksruimte **showroom** bevat een verzameling technieken die als doel hebben de oplossing geschikter te maken voor hergebruik. Het kan hierbij bijvoorbeeld gaan om methoden die helpen een oplossing te positioneren ten opzichte van ander beschikbaar werk.

  

# 3. Projectorganisatie

### Teamleden

De betrokken belangengroepen zijn de docenten van semester. Ook de leden van de projectgroep en de projectmanager zijn belanghebbenden. Zij zijn studenten en gebruiken zelf de te ontwikkelen applicatie.

Deze projectgroep bestaat vooralsnog uit 1 persoon. Deze persoon is verantwoordelijk voor alles wat er met dit project te maken heeft.

## Communicatie

De projectgroep komt elke week samen om te overleggen, de voortgang te bespreken en de volgende (sub)taken te bepalen. Na elke bijeenkomst is duidelijk wat er gedaan moet worden en voor wanneer dit klaar is. Er vindt driewekelijks een oplevering plaats van alle onderdelen die in de periode daarvoor opgeleverd zijn. Aan de hand van deze opleveringen wordt de voortgang van het project bijgehouden.

  

# 4. Activiteiten en tijdplan

Dit project is onderverdeeld in 5 iteraties van 3 weken. Elke iteratie bevat een reflectie op de leeruitkomsten zoals die in de opdracht vermeld staan. Bij elke iteratie zal ook het niveau aangegeven worden, dit dient onderbouwd te zijn met bewijsstukken in de vorm van documenten, code of feedback.

**Iteratie**

**Startweek**

**Eindweek**

**Effort**

**EPIC’s**

**Iteratie 1**

1

(6-maart-2023)

3

(5-maart-2023)

Scope afbakening

Vooronderzoek blockchain-technologie en tech stacks

**Iteratie 2**

4

7

Tech stack bepalen

Keuze blockchain-tech stack

Vergelijkingsonderzoek frontend frameworks

**Iteratie 3**

8

11

POC

Inventarisatie Available Work en Application Domain

Proof of concept

**Iteratie 4**

12

15

POC

Proof of concept

**Iteratie 5**

16

19

POC

Oplevering

Proof of concept

Tabel 3 Iteraties

  

# 5. Leeruitkomsten

## Analyseren

Uitvoeren van een requirementsanalyse voor een softwaresysteem met verschillende belanghebbenden in een context van bestaande systemen. Definiëren van acceptatiecriteria aan de hand van kwaliteitseigenschappen en een uitgevoerde risicoanalyse met onder andere aandacht voor security aspecten.

## Adviseren

Adviseren met betrekking tot de keuze voor softwarearchitectuur of bestaande software frameworks, waarbij kostenaspecten en kwaliteitskenmerken zoals beschikbaarheid, performance en security een rol spelen. Adviseren over de aanpak bij het verwerken en raadplegen van grote hoeveelheden data met aandacht voor privacy. Adviseren over de inrichting van een softwareontwikkelproces, waaronder het testproces.

## Ontwerpen

Opstellen van een softwarearchitectuur voor een softwaresysteem, opgebouwd uit bestaande en nieuwe systemen, rekening houdend met meerdere belanghebbenden en kwaliteitskenmerken, waaronder security. Opstellen van teststrategie voor systeemtesten.

## Realiseren

Bouwen en beschikbaar stellen van een softwaresysteem dat aansluit bij bestaande systemen, eventueel in de cloud, volgens de ontworpen architectuur met gebruik van bestaande frameworks. Toepassen van testautomatisering bij het uitvoeren van testen.

## Manage & Control

Uitvoeren van configuratie-, change- en releasemanagement in afstemming met infrastructuur-management. Inrichten van een ontwikkelstraat met geautomatiseerde build en test infrastructuur.

## Kritisch denken

Je bent in staat om vanuit een ongestructureerde praktijkvraagstelling in alle stadia van het methodisch proces passende (deel)vragen te formuleren en zelfstandig onderzoeksmethoden te selecteren, uit te voeren en te onderbouwen aan de hand van onderzoeksstrategieën om de deugdelijkheid van zijn onderzoek aantonen. Bovendien laat je zien dat je in je analyse rekening houdt met maatschappelijke, internationale, wetenschappelijke en ethische aspecten.

## Communicatie

Je bent in staat om de uitvoering van een omvangrijke beroepsopdracht in een realistische context zowel mondeling als schriftelijk te verantwoorden en te verdedigen en de schrijfstijl aan te passen aan het beoogde publiek in het Nederlands of het Engels. Ook ben je in staat om effectief in teamverband te werken bij het zelfstandig uitvoeren van een professionele opdracht. Bovendien kun je goed functioneren en werken in een internationale of interculturele omgeving, zowel binnen als buiten de hogeschool.

## Leervaardigheid

Je kunt je professionele talenten en ontwikkelingsambities in relatie tot het ICT-vak beschrijven, maar ook reflecteren op en feedback krijgen op je eigen functioneren in het ICT-vak. Je toont initiatief en hebt een zelfstandige houding waarin je zelfstandig en resultaatgericht werkt aan professionele opdrachten buiten de hogeschool.

# 6. Product Breakdown Structure

**Proof-of-concept**                    

![Tekstvak: (Decentralised) Web App
Functionele requirements
•	Een gebruiker moet met behulp van een formulier een product kunnen toevoegen aan de product store
•	Een gebruiker moet een product kunnen kopen door middel van een knop bij de advertentie.
Non-functionele requirements
•	Nadat een gebruiker een product heeft toegevoegd mag het (her)laden en tonen maximaal 5s duren
pp](file:///C:/Users/ICT89/AppData/Local/Temp/msohtmlclip1/01/clip_image003.png)

**Onderzoek en Documentatie**
![Tekstvak: Front-end frameworks
Functionele requirements
•	Een gebruiker moet met behulp van een formulier een product kunnen toevoegen aan de product store
•	Een gebruiker moet een product kunnen kopen door middel van een knop bij de advertentie.
Non-functionele requirements
•	Nadat een gebruiker een product heeft toegevoegd mag het (her)laden en tonen maximaal 5s duren
pp](file:///C:/Users/ICT89/AppData/Local/Temp/msohtmlclip1/01/clip_image004.png)

![Tekstvak: Blockchain-technologie
Functionele requirements
•	Een gebruiker moet met behulp van een formulier een product kunnen toevoegen aan de product store
•	Een gebruiker moet een product kunnen kopen door middel van een knop bij de advertentie.
Non-functionele requirements
•	Nadat een gebruiker een product heeft toegevoegd mag het (her)laden en tonen maximaal 5s duren
pp](file:///C:/Users/ICT89/AppData/Local/Temp/msohtmlclip1/01/clip_image005.png)

 

 

  

# 7. Bronnen

Nations, U. (2022). — SDG Indicators. Retrieved February 12, 2023, from Un.org website: https://unstats.un.org/sdgs/report/2021/goal-12/

‌The DOT Framework - ICT research methods. (2021). Retrieved February 14, 2023, from Ictresearchmethods.nl website: https://ictresearchmethods.nl/The_DOT_Framework#The_Development_Oriented_Triangulation_Framework

‌Upadhyay, A., Mukhuty, S., Kumar, V., & Kazancoglu, Y. (2021). Blockchain technology and the circular economy: Implications for sustainability and social responsibility. _Journal of Cleaner Production_, _293_, 126130. https://doi.org/10.1016/j.jclepro.2021.126130

‌